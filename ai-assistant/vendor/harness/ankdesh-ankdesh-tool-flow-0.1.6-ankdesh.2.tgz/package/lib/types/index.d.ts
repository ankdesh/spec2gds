/** Named composite model tools generated from developer flow definitions. */
import type { Context } from '@ankdesh/cordis';
import z from '@ankdesh/schemastery';
import type { Agent } from '@ankdesh/dsh-agent';
import type { FlowRuntime } from '@ankdesh/ankdesh-flow';
export declare const name = "tool-flow";
export declare const inject: string[];
/** Generate scoped tools; authority and context come from the host, not arguments.
 * @param agent - Live conversation.
 * @param flows - Executor.
 * @param context - Host-selected publication context.
 * @returns All registration disposers.
 */
export declare function registerFlowTools(agent: Agent, flows: FlowRuntime, context: string): () => void;
/** Generic profiles use an explicit context; product integrations register scoped tools directly. */
export interface Config {
    /** Host-selected publication context for this deployment. */
    context: string;
}
/** Host-selected publication context; the model cannot override it. */
export declare const Config: z<Config>;
/** Mount named tools into future conversations and remove them on teardown.
 * @param ctx - Composition.
 * @param config - Explicit publication context.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map