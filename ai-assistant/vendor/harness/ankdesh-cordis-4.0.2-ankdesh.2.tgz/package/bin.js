#!/usr/bin/env node

import { Context } from '@ankdesh/cordis'
import { pathToFileURL } from 'node:url'
import Loader from '@ankdesh/cordis-plugin-loader'

const ctx = new Context()
ctx.baseUrl = pathToFileURL(process.cwd()).href + '/'

await ctx.plugin(Loader)
await ctx.loader.create({
  name: '@ankdesh/cordis-plugin-include',
  config: {
    path: './cordis.yml',
  },
})
