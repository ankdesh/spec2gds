/** Shared reservation and settlement rules for bounded native execution. */
import type { TokenUsage } from '@ankdesh/dsh-llm/types';
/** Reserve conservative request capacity before provider access.
 * @param envelope - Exact serialized messages, system prompt, and tool schemas.
 * @param maxOutputTokens - Explicit output allowance.
 * @param measuredContextTokens - Existing replay-aware context measurement.
 * @returns Conservative input plus output capacity.
 */
export declare function reserveRequestTokens(envelope: unknown, maxOutputTokens: number, measuredContextTokens?: number): number;
/** Sum provider-reported disjoint token buckets; reasoning is an output subset.
 * @param usage - Correlated provider usage, when available.
 * @returns Actual spending, or undefined to retain a conservative reservation.
 */
export declare function reportedRequestTokens(usage: TokenUsage | undefined): number | undefined;
/** Settle exactly once at the caller's persisted receipt boundary.
 * @param reserved - Committed conservative capacity.
 * @param reported - Validated correlated usage; undefined preserves uncertainty.
 * @returns The charge retained for this request.
 */
export declare function settleRequestTokens(reserved: number, reported: number | undefined): number;
//# sourceMappingURL=request-accounting.d.ts.map