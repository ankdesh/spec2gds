import { Context, Service } from '@ankdesh/cordis';
import z from '@ankdesh/schemastery';
import type { FlowDefinition } from '@ankdesh/ankdesh-flow';
/** Explicit trusted roots and whole-file bounds. */
export interface Config {
    /** Trusted definition files or catalog directories. */
    roots: string[];
    /** Maximum bytes in each definition file. */
    maxFileBytes: number;
    /** Maximum bytes in each referenced instruction file. */
    maxInstructionBytes: number;
}
export declare const Config: z<Config>;
/** Strict no-code YAML parser; external instructions require an explicit file resolver.
 * @param text - Developer-authored YAML.
 * @param source - Source diagnostic.
 * @param maxBytes - Whole-file limit.
 * @param instruction - Trusted instruction-file resolver.
 * @returns Validated definition.
 */
export declare function parseFlowYaml(text: string, source: string, maxBytes: number, instruction?: (path: string) => string): FlowDefinition;
/** Loader provider; registrations unwind with its plugin fiber. */
export declare class FlowYamlProvider extends Service {
    static inject: string[];
    static Config: z<Config>;
    /** Mount this service in the native composition.
     * @param ctx - Composition.
     * @param config - Trusted deployment paths.
     */
    constructor(ctx: Context, config: Config);
}
declare module '@ankdesh/cordis' {
    interface Context {
        flowYaml: FlowYamlProvider;
    }
}
export default FlowYamlProvider;
//# sourceMappingURL=index.d.ts.map