import type { Context } from '@ankdesh/cordis';
export declare const name = "flow-text-example";
export declare const inject: string[];
/** Register two pure operations and data definitions.
 * @param ctx - Generic flow composition.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=example.d.ts.map