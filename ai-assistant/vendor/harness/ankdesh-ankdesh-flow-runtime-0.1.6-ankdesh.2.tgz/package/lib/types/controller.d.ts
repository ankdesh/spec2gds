/** Human-facing scoped control over the same flow commands used by model tools. */
import { Context } from '@ankdesh/cordis';
import type { Agent } from '@ankdesh/dsh-agent';
import { TypertRemoteService } from '@ankdesh/dsh-typert-protocol';
import type { FlowControl, FlowExecutionId, FlowRef, FlowSummary } from '@ankdesh/ankdesh-flow/types';
import type { JsonValue } from '@ankdesh/dsh-util-values';
/** Optional Typert consumer; transport callers cannot set execution state. */
export declare class FlowController extends TypertRemoteService {
    static inject: string[];
    /** Mount this service in the native composition.
     * @param ctx - Native remote composition.
     */
    constructor(ctx: Context);
    /** Use the declared caller and configuration.
     * @param agent - Resolved caller.
     * @param definition - Published pinned version.
     * @param context - Eligible deployment context.
     * @param inputs - Typed arguments.
     * @param requestId - Stable caller identity.
     * @returns Accepted execution summary.
     */
    start(agent: Agent, definition: FlowRef, context: string, inputs: JsonValue, requestId: string): Promise<FlowSummary>;
    /** Use the declared caller and configuration.
     * @param agent - Resolved caller.
     * @param id - Execution identity.
     * @returns Its current summary.
     */
    get(agent: Agent, id: FlowExecutionId): Promise<FlowSummary>;
    /** Use the declared caller and configuration.
     * @param agent - Resolved caller conversation.
     * @returns Its recent execution summaries.
     */
    list(agent: Agent): Promise<FlowSummary[]>;
    /** Use the declared caller and configuration.
     * @param agent - Resolved caller.
     * @param id - Execution.
     * @param revision - Observed revision.
     * @param command - Human command.
     * @returns Committed summary.
     */
    control(agent: Agent, id: FlowExecutionId, revision: number, command: FlowControl): Promise<FlowSummary>;
    /** Use the declared caller and configuration.
     * @param agent - Resolved caller.
     * @param id - Execution.
     * @param revision - Observed revision.
     * @param waitId - Exact wait.
     * @param deliveryId - Stable response.
     * @param value - Typed response.
     * @returns Committed summary.
     */
    answer(agent: Agent, id: FlowExecutionId, revision: number, waitId: string, deliveryId: string, value: JsonValue): Promise<FlowSummary>;
    /** Use the declared caller and configuration.
     * @param agent - Resolved caller.
     * @param id - Execution.
     * @returns Offline trace, without model or service access.
     */
    trace(agent: Agent, id: FlowExecutionId): Promise<JsonValue>;
}
declare module '@ankdesh/cordis' {
    interface Context {
        flowController: FlowController;
    }
}
export default FlowController;
//# sourceMappingURL=controller.d.ts.map