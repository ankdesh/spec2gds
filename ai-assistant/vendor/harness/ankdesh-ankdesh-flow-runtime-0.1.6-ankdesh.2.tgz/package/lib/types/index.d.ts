import { Context } from '@ankdesh/cordis';
import z from '@ankdesh/schemastery';
import { FlowRuntime } from '@ankdesh/ankdesh-flow';
import type { CompiledFlow, FlowActor, FlowControl, FlowDefinition, FlowExecutionId, FlowLimits, FlowModelProvider, FlowOperation, FlowRef, FlowStart, FlowView } from '@ankdesh/ankdesh-flow';
import type { SessionId } from '@ankdesh/dsh-session';
import type { JsonValue } from '@ankdesh/dsh-util-values';
export { flowView, transitionFlow } from './transition.ts';
/** Explicit deployment limits. */
export interface Config extends FlowLimits {
}
export declare const Config: z<Config>;
/** Write uncertainty is explicit; known domain validation failures stop. */
export declare class FlowOperationError extends Error {
    readonly uncertain: boolean;
    /** Mount this service in the native composition.
     * @param message - Diagnostic.
     * @param uncertain - Whether an effect may have committed.
     */
    constructor(message: string, uncertain: boolean);
}
/** Native provider; persistent records are the sole execution authority. */
export declare class DurableFlowRuntime extends FlowRuntime {
    private readonly config;
    static inject: string[];
    static Config: z<Config>;
    readonly ready: Promise<void>;
    private table;
    private readonly definitions;
    private readonly operations;
    private model;
    private readonly drivers;
    private queue;
    private closing;
    private readonly waiters;
    /** Mount this service in the native composition.
     * @param ctx - Native composition.
     * @param config - Explicit limits.
     */
    constructor(ctx: Context, config: Config);
    registerDefinition(definition: FlowDefinition): () => void;
    registerOperation(operation: FlowOperation): () => void;
    registerModelProvider(provider: FlowModelProvider): () => void;
    catalog(context: string): readonly FlowDefinition[];
    compile(ref: FlowRef): CompiledFlow;
    private serial;
    private validatePinned;
    private read;
    private authorize;
    get(id: FlowExecutionId, actor: FlowActor): FlowView;
    list(actor: FlowActor): readonly FlowView[];
    active(session: SessionId): boolean;
    trace(id: FlowExecutionId, actor: FlowActor): FlowView;
    private commit;
    private update;
    start(request: FlowStart): Promise<FlowView>;
    reserveModelEnvelope(id: FlowExecutionId, operationId: string, tokens: number): Promise<void>;
    advance(id: FlowExecutionId): void;
    settled(id: FlowExecutionId): Promise<FlowView>;
    control(id: FlowExecutionId, revision: number, command: FlowControl, actor: FlowActor): Promise<FlowView>;
    answer(id: FlowExecutionId, revision: number, waitId: string, deliveryId: string, value: JsonValue, actor: FlowActor): Promise<FlowView>;
    reportWaitDiagnostic(id: FlowExecutionId, revision: number, waitId: string, message: string | undefined, actor: FlowActor): Promise<FlowView>;
    private deliverControls;
    private settleActive;
    private finished;
    private context;
    private drive;
}
export default DurableFlowRuntime;
export { FlowController } from './controller.ts';
//# sourceMappingURL=index.d.ts.map