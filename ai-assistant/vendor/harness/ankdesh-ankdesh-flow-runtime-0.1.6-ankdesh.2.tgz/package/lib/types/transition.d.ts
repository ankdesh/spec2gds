import type { FlowControl, FlowExecution, FlowView } from '@ankdesh/ankdesh-flow';
/** Derive permitted human controls.
 * @param record - Durable execution.
 * @returns Read view.
 */
export declare function flowView(record: FlowExecution): FlowView;
/** Apply one revision-checked named command without effects.
 * @param record - Current execution.
 * @param revision - Caller observation.
 * @param command - Requested command.
 * @param timestamp - Commit time.
 * @returns New execution.
 */
export declare function transitionFlow(record: FlowExecution, revision: number, command: FlowControl, timestamp: number): FlowExecution;
//# sourceMappingURL=transition.d.ts.map