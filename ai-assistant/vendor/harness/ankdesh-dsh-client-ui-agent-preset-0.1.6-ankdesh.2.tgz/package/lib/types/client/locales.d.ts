/** Locale bundles for the agent-preset hero chip, header label, and management section. */
/** Locale keys these surfaces render. */
export type AgentPresetSettingsKey = 'error' | 'userTrust' | 'seatHint' | 'headerHint' | 'nav' | 'sectionIntro' | 'builtIn' | 'setDefault' | 'view' | 'presetStandardName' | 'presetStandardDescription' | 'presetPtcName' | 'presetPtcDescription' | 'presetMinimalName' | 'presetMinimalDescription' | 'presetCordisName' | 'presetCordisDescription' | 'duplicate' | 'duplicateUnavailable' | 'delete' | 'presetId' | 'presetIdPlaceholder' | 'copyOf' | 'displayName' | 'displayNamePlaceholder' | 'inUse' | 'selectionOffDefault' | 'noDescription' | 'builtInGroup' | 'customGroup' | 'brokenBadge' | 'brokenNoCopy' | 'switchRefused' | 'composition' | 'cancel' | 'close' | 'retry' | 'copyTitle' | 'copyIntro' | 'create' | 'creating' | 'creatorDraft' | 'openLocation' | 'showLocation' | 'revealedPathLabel' | 'idRequired' | 'idInvalid' | 'idTaken' | 'deleteTitle' | 'deleteDescription' | 'deleteConfirm' | 'deleting' | 'showPicker' | 'showPickerBeta' | 'showPickerDescription' | 'enablePickerToSetDefault' | 'enablePickerToCreate';
/** English copy. */
export declare const en: Record<AgentPresetSettingsKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<AgentPresetSettingsKey, string>;
export { presetDisplayText } from '@ankdesh/dsh-agent-presets/display';
export type { PresetDisplaySource, PresetDisplayText } from '@ankdesh/dsh-agent-presets/display';
//# sourceMappingURL=locales.d.ts.map