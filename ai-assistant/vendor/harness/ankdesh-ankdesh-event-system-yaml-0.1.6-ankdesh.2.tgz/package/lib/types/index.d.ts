import { Context, Service } from '@ankdesh/cordis';
import z from '@ankdesh/schemastery';
import type { EventSystemDefinition } from '@ankdesh/ankdesh-event-system';
/** Required trusted roots and byte limits; templates are read once. */
export interface Config {
    /** Trusted files or immediate-child directories to load at startup. */
    roots: string[];
    /** Maximum UTF-8 byte length of each YAML definition. */
    maxFileBytes: number;
    /** Maximum UTF-8 byte length of each contained Markdown prompt. */
    maxPromptBytes: number;
}
export declare const Config: z<Config>;
declare module '@ankdesh/cordis' {
    interface Context {
        eventSystemsYaml: EventSystemYamlProvider;
    }
}
/**
 * Parse strict YAML, resolve contained Markdown prompt files, then validate every reference.
 * @param text - untrusted YAML file text.
 * @param source - absolute definition filename.
 * @param limits - explicit YAML and prompt byte limits.
 * @returns validated definition with resolved Markdown text.
 */
export declare function parseEventSystemYaml(text: string, source: string, limits: Pick<Config, 'maxFileBytes' | 'maxPromptBytes'>): EventSystemDefinition;
/** Register startup templates and release all registrations on disposal. */
export default class EventSystemYamlProvider extends Service {
    static inject: string[];
    static Config: z<Config>;
    constructor(ctx: Context, config: Config);
}
//# sourceMappingURL=index.d.ts.map