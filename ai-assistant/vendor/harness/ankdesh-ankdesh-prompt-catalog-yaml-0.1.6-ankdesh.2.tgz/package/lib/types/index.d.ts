import { Context, Service } from '@ankdesh/cordis';
import z from '@ankdesh/schemastery';
import type { PromptBundle } from '@ankdesh/ankdesh-prompt-catalog';
export interface Config {
    /** Trusted bundle files or non-recursive directories loaded once at startup. */
    roots: string[];
}
export declare const Config: z<Config>;
declare module '@ankdesh/cordis' {
    interface Context {
        promptCatalogYaml: PromptCatalogYamlProvider;
    }
}
export declare function parsePromptBundleYaml(text: string, source?: string): PromptBundle;
/** Startup barrier proving every configured prompt bundle is registered. */
export declare class PromptCatalogYamlProvider extends Service {
    static inject: string[];
    static Config: z<Config>;
    constructor(ctx: Context, config: Config);
}
export default PromptCatalogYamlProvider;
//# sourceMappingURL=index.d.ts.map