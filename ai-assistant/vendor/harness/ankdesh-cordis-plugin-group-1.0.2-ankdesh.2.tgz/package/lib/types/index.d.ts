import { Group } from '@ankdesh/cordis-plugin-loader';
export default Group;
//# sourceMappingURL=index.d.ts.map