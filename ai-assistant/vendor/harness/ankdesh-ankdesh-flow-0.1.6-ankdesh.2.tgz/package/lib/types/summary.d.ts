/** Small read shared by remote and product UI consumers. */
import type { FlowSummary, FlowView } from './types.ts';
/** Crop private drafts and definitions from progress reads.
 * @param view - Committed execution view.
 * @returns Status, exact revision, controls and final result.
 */
export declare function summarizeFlow(view: FlowView): FlowSummary;
//# sourceMappingURL=summary.d.ts.map