import type { JsonSchemaNode } from '@ankdesh/dsh-tools';
import type { JsonValue } from '@ankdesh/dsh-util-values';
import type { CompiledFlow, FlowDefinition, FlowOperation, FlowRef, FlowValue } from './types.ts';
/** Stable identity independent of JSON property order.
 * @param value - JSON data.
 * @returns SHA-256 identity.
 */
export declare function flowDigest(value: unknown): string;
/** Exact catalog key.
 * @param ref - Named version.
 * @returns Key.
 */
export declare function flowKey(ref: FlowRef): string;
/** Enforce a schema at file, model, service, or persistence admission.
 * @param schema - Supported schema.
 * @param value - Candidate JSON.
 * @param where - Diagnostic location.
 */
export declare function assertFlowValue(schema: JsonSchemaNode, value: unknown, where: string): void;
/** Resolve typed references recursively without coercing values.
 * @param value - Literal or reference tree.
 * @param inputs - Local inputs.
 * @param outputs - Committed local outputs.
 * @returns Detached JSON value.
 */
export declare function resolveFlowValue(value: FlowValue, inputs: JsonValue, outputs: Readonly<Record<string, JsonValue>>): JsonValue;
/** Validate developer-authored data before registering it.
 * @param input - Untrusted YAML or JSON.
 * @returns Detached typed definition.
 */
export declare function defineFlow(input: FlowDefinition): FlowDefinition;
/** Validate a code operation's recovery declaration.
 * @param operation - Typed operation.
 * @returns The operation.
 */
export declare function defineOperation<I, O>(operation: FlowOperation<I, O>): FlowOperation<I, O>;
/** Compile an acyclic graph and its exact subflows without invoking operations.
 * @param definition - Registered root definition.
 * @param definitions - Exact definition lookup.
 * @param operations - Exact operation lookup.
 * @param maxNodes - Maximum expanded nodes.
 * @param ancestry - Internal recursion check.
 * @returns Immutable compiled graph.
 */
export declare function compileFlow(definition: FlowDefinition, definitions: ReadonlyMap<string, FlowDefinition>, operations: ReadonlyMap<string, FlowOperation>, maxNodes: number, ancestry?: readonly string[]): CompiledFlow;
//# sourceMappingURL=compiler.d.ts.map