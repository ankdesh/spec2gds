/**
 * Startup-owned, immutable prompt bundle catalog.
 * @module @ankdesh/ankdesh-prompt-catalog
 */
import { Context, Service } from '@ankdesh/cordis';
export declare const MAX_PROMPT_TEXT_BYTES: number;
export declare const MAX_PROMPT_BUNDLE_BYTES: number;
export declare const MAX_BOUND_PROMPT_BYTES: number;
export interface PromptBundleSection {
    readonly id: string;
    readonly order: number;
    readonly text: string;
}
export interface PromptBundle {
    readonly apiVersion: 'dsh.deepseek.ai/v1';
    readonly kind: 'PromptBundle';
    readonly metadata: {
        readonly id: string;
        readonly version: string;
    };
    readonly sections: readonly PromptBundleSection[];
    readonly texts?: Readonly<Record<string, string>>;
}
export interface PromptBundleRef {
    readonly id: string;
    readonly version: string;
}
export interface PromptCatalogEntry {
    readonly bundle: PromptBundle;
    readonly digest: `sha256:${string}`;
    readonly source: string;
}
export interface BoundPromptBundle {
    readonly ref: PromptBundleRef;
    readonly digest: `sha256:${string}`;
    readonly sections: readonly PromptBundleSection[];
    readonly texts: Readonly<Record<string, string>>;
}
declare module '@ankdesh/cordis' {
    interface Context {
        promptCatalog: PromptCatalog;
    }
}
/** Stable JSON form used for content identity. */
export declare function canonicalJson(value: unknown): string;
/** Validate and detach a bundle before it enters the catalog. */
export declare function validatePromptBundle(value: PromptBundle): PromptBundle;
/** Immutable after startup sealing; registrations remain effect-owned for teardown. */
export declare class PromptCatalog extends Service {
    private readonly entries;
    private sealed;
    constructor(ctx: Context);
    register(input: PromptBundle, source?: string): () => void;
    get(ref: PromptBundleRef): PromptCatalogEntry;
    list(): readonly PromptCatalogEntry[];
    bind(ref: PromptBundleRef, variables?: Readonly<Record<string, string>>): BoundPromptBundle;
    seal(): void;
    isSealed(): boolean;
    private key;
}
export default PromptCatalog;
//# sourceMappingURL=index.d.ts.map