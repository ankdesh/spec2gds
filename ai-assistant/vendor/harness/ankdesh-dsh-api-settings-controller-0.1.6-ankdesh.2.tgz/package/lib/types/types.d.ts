/**
 * Browser-safe failure vocabulary of the configuration surfaces this package
 * serves. The redacted views themselves live with their seam in
 * `@ankdesh/dsh-settings/types`, whose Cordis event declarations already
 * register that file for the Client compilation face.
 *
 * @module @ankdesh/dsh-api-settings-controller/types
 */
declare module '@ankdesh/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        /**
         * Every seam refusal that is not a stale write: an unregistered or malformed
         * namespace, a read-only provider, schema validation, storage.
         */
        'settings/rejected': {
            readonly ns: string;
        };
        /**
         * The stored revision moved after the caller read it. Its own outcome rather
         * than an invalid request: the caller must re-read and re-apply.
         */
        'settings/conflict': {
            readonly ns: string;
            readonly expected: number;
            readonly actual: number;
        };
        /**
         * The provider refused a valid credential write, for example because a
         * read-only source shadows the reference. The details name only the
         * reference, never the value.
         */
        'credential/rejected': {
            readonly ref: string;
        };
    }
}
/** Confirmation that the settings document was handed to the native editor. */
export interface SettingsDocumentOpenValue {
    readonly opened: true;
}
/** Result of opening or revealing one locally authored Agent preset directory. */
export type AgentPresetDirectoryOpenValue = {
    readonly opened: true;
} | {
    readonly opened: false;
    readonly path: string;
};
//# sourceMappingURL=types.d.ts.map