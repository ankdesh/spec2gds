/** Build-static first-party Session format migration catalog. */
export { sessionFormatCatalog } from './generated.ts';
export { SessionFormatUnsupportedMigrationError } from '@ankdesh/dsh-session-format';
//# sourceMappingURL=index.d.ts.map