/** Platform-neutral assembly of generated Host Remote contributions. */
import type { Context } from '@ankdesh/cordis';
import type { ClientRemote } from '@ankdesh/dsh-api-gateway/client';
export type { ClientRemote } from '@ankdesh/dsh-api-gateway/client';
export type { PluginInventorySnapshot } from '@ankdesh/dsh-host-plugin-inventory/types';
export type {} from '@ankdesh/dsh-agent-presets/remote';
export type {} from '@ankdesh/dsh-commands/remote';
export type {} from '@ankdesh/dsh-api-settings-controller/remote';
export type {} from '@ankdesh/ankdesh-flow-runtime/remote';
export type {} from '@ankdesh/ankdesh-flow/types';
export type {} from '@ankdesh/dsh-goal/remote';
export type {} from '@ankdesh/dsh-llm/remote';
export type {} from '@ankdesh/dsh-host-plugin-inventory/remote';
export type {} from '@ankdesh/dsh-message-feedback/remote';
export type {} from '@ankdesh/dsh-permission-presets/remote';
export type {} from '@ankdesh/dsh-command-feedback/remote';
export type {} from '@ankdesh/dsh-client-file-upload/remote';
export type {} from '@ankdesh/dsh-session-reference/remote';
export type {} from '@ankdesh/dsh-subagent/remote';
export type * from '@ankdesh/dsh-subagent/client';
export type {} from '@ankdesh/dsh-api-session-controller/remote';
export type * from '@ankdesh/dsh-api-session-controller/types';
export type {} from '@ankdesh/dsh-api-workspace-controller/remote';
export type * from '@ankdesh/dsh-api-workspace-controller/types';
export type {} from '@ankdesh/dsh-api-workspace-files/remote';
export type * from '@ankdesh/dsh-api-workspace-files/types';
export type {} from '@ankdesh/dsh-api-terminal-controller/remote';
export type * from '@ankdesh/dsh-api-terminal-controller/types';
export type { SessionJob as JobView } from '@ankdesh/dsh-api-session-controller/types';
export type { ApiRemoteForwardedEvent } from '../types.ts';
export type {} from '@ankdesh/dsh-commands/types';
export type {} from '@ankdesh/dsh-cordis-host-runner/types';
export type {} from '@ankdesh/dsh-credentials/types';
export type {} from '@ankdesh/dsh-llm/types';
export type {} from '@ankdesh/dsh-agent-presets/types';
export type {} from '@ankdesh/dsh-permission-presets/types';
export type {} from '@ankdesh/dsh-settings/types';
export type {} from '@ankdesh/dsh-user-approval/types';
export type {} from '@ankdesh/dsh-user-questions/types';
export type {} from '@ankdesh/dsh-api-session-controller/types';
/**
 * The carrier's Client-facing types, re-exported so a business package names one
 * assembly package instead of both this facade and the Connection plugin. Type-only:
 * the carrier's runtime values stay behind their own module edge.
 */
export type { ConnectionHandle, ConnectionSinks, ContentBlock, MessageId, RpcId, RpcRequest, RpcResponse, RpcResult, SessionId, StreamChunk, } from '@ankdesh/dsh-client-connection/client';
export type {} from '@ankdesh/dsh-api-gateway/client';
export type {} from '@ankdesh/dsh-cordis-host-runner/remote';
export type { ApprovalRequestId, CordisHalfState, CordisDynamicPackageId, CordisDynamicPluginId, CordisDynamicPluginRunId, CordisDynamicRunMode, CordisInspectMethodManifest, CordisInspectPlatform, CordisInspectProviderManifest, CordisInspectProviderView, CordisInspectQueryRequest, CordisInspectQueryResolution, CordisInspectQueryResolved, CordisInspectRequestId, CordisInspectResolveAck, CordisRunDiagnostic, CordisRunStatus, DynamicCordisClientSource, DynamicCordisHostHalfResult, DynamicCordisInventoryRow, DynamicCordisInvokeResult, DynamicCordisPackage, DynamicCordisRequestResolved, DynamicCordisResolveAck, DynamicCordisRetracted, DynamicCordisRunRequest, DynamicCordisRunResolution, DynamicCordisRunAttempt, DynamicCordisRunResponse, DynamicCordisStopResponse, DynamicCordisUndefineReceipt, RequestRunOutcome, } from '@ankdesh/dsh-cordis-host-runner/types';
export type { CredentialInfo } from '@ankdesh/dsh-credentials/types';
export type { SettingsDescribeValue, SettingsNamespaceView, SettingsPathOpView, SettingsSecretView, } from '@ankdesh/dsh-settings/types';
export type { LlmConfigurableProvider, LlmDiscoveredModel, LlmModelDiscoveryRequest, LlmProviderInfo, } from '@ankdesh/dsh-llm/types';
export type { FileReferenceCandidate } from '@ankdesh/dsh-file-reference/types';
export type { SessionReferenceMentionCandidate } from '@ankdesh/dsh-session-reference/types';
export type { RemoteErrorCode, RemoteErrorDetailsMap, RemoteFailure, RemoteResult, } from '@ankdesh/dsh-typert-protocol';
export type { RemoteHostFacts } from '@ankdesh/dsh-api-gateway/client';
declare module '@ankdesh/cordis' {
    interface Context {
        /** Generated Remote namespaces selected by this Client assembly. */
        remote: ClientRemote;
    }
}
/** Required service: the typed Client Remote contribution mount. */
export declare const inject: string[];
/**
 * Mount the Host capabilities explicitly selected for this Client assembly.
 * @param ctx - Client Cordis root carrying the typed API service.
 * @returns disposer after every selected Remote namespace is ready.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map