import type { Context } from '@ankdesh/cordis';
import type { SessionEvent } from '@ankdesh/dsh-session';
import type { Agent } from '@ankdesh/dsh-agent';
import type { FlowModelNode, FlowModelProvider, FlowModelResult, FlowOperationContext, FlowLimits } from '@ankdesh/ankdesh-flow';
import type { JsonValue } from '@ankdesh/dsh-util-values';
import type { SessionId } from '@ankdesh/dsh-session';
declare module '@ankdesh/cordis' {
    interface Events {
        /** Bind host policies to one phase scope.
         * @param payload - Exact native phase and source.
         * @mode serial
         */
        'flow/model-phase'(payload: {
            agent: Agent;
            executionId: FlowOperationContext['executionId'];
            sourceSessionId: SessionId;
            instructions: string;
            scope: Context;
        }): void | Promise<void>;
        /** A native phase inbox receipt has been persisted.
         * @param payload - Exact execution and destination.
         * @mode serial
         */
        'flow/model-input-accepted'(payload: {
            executionId: FlowOperationContext['executionId'];
            agent: Agent;
        }): void | Promise<void>;
    }
}
export declare const name = "flow-model-native";
export declare const inject: string[];
/** Stable phase inbox identity.
 * @param context - Recorded operation identity.
 * @returns Identified native message.
 */
export declare function flowPhaseMessageId(context: FlowOperationContext): string;
/** Inspect a committed native phase; idle is never treated as a result.
 * @param events - Events read from native persistence.
 * @param node - Pinned phase schema.
 * @param context - Recorded operation.
 * @returns Committed structured result, if present.
 */
export declare function readFlowPhaseResult(events: readonly SessionEvent[], node: FlowModelNode, context: FlowOperationContext): FlowModelResult | undefined;
/** Read committed native events without synchronous historical Session access.
 * @param ctx - Native persistence composition.
 * @param conversation - Exact recorded conversation.
 * @returns Validated committed event sequence for receipt correlation.
 */
export declare function persistedFlowEvents(ctx: Context, conversation: SessionId): Promise<readonly SessionEvent[]>;
/** Native phase provider; only the result-reporting tool may execute. */
export declare class NativeFlowModelProvider implements FlowModelProvider {
    private readonly ctx;
    /** Mount this service in the native composition.
     * @param ctx - Native Harness composition.
     */
    constructor(ctx: Context);
    reconcile(node: FlowModelNode, conversation: SessionId, context: FlowOperationContext): Promise<FlowModelResult | undefined>;
    execute(node: FlowModelNode, inputs: JsonValue, conversation: SessionId, context: FlowOperationContext, limits: FlowLimits): Promise<FlowModelResult>;
}
/** Register the native phase provider as a reversible effect.
 * @param ctx - Native composition.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map