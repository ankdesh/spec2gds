/** Compare committed model outputs with independently recorded native result receipts. */
import type { Context } from '@ankdesh/cordis';
export declare const name = "flow-model-native-invariant";
export declare const inject: string[];
/** Register native-receipt observations through exact companion disposal.
 * @param ctx - Invariant composition.
 */
export declare const apply: (ctx: Context) => void;
//# sourceMappingURL=invariant.d.ts.map