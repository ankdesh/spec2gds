import { type Branded, type BrandedNumber } from '@ankdesh/dsh-brand';
import type { AssistantMessage, AssistantStreamRecord, ToolCallId, LlmCallConfig, LlmCallConfigAdapterDefaults, LlmFailure, SystemMessage, SystemPromptUpdate, TokenUsage, ToolResultMessage, ToolSchema, UserMessage } from '@ankdesh/dsh-llm';
import type { JsonValue } from '@ankdesh/dsh-util-values';
/** Identifies one session in the store (and its persistence artifacts). */
export type SessionId = Branded<'SessionId'>;
/**
 * Brand a string as a {@link SessionId}.
 * @param id - the raw session id string.
 * @returns the same string with the session-id brand.
 */
export declare function SessionId(id: string): SessionId;
/** Sequence number of one existing event in a Session log. */
export type SessionSeq = BrandedNumber<'SessionSeq'>;
/**
 * Admit a numeric value as an existing Session event position.
 * @param value - non-negative safe integer admitted by the owning log operation.
 * @returns the same number with the Session-sequence brand.
 */
export declare function SessionSeq(value: number): SessionSeq;
/** A Session log gap, prefix length, or read offset, which may equal the event count. */
export type SessionLogOffset = BrandedNumber<'SessionLogOffset'>;
/**
 * Admit a numeric value as a Session log offset.
 * @param value - non-negative safe integer used as a gap or prefix length.
 * @returns the same number with the Session-log-offset brand.
 */
export declare function SessionLogOffset(value: number): SessionLogOffset;
/** Inclusive Session event watermark, or `-1` before any event exists. */
export type SessionSeqCursor = SessionSeq | -1;
/** One existing Session event position, or explicit absence. */
export type OptionalSessionSeq = SessionSeq | null;
/**
 * Current logical Session format version, stamped into every newly written
 * {@link SessionHeader}. Current Session and persistence code accept only this
 * value; header-only readers classify supported historical formats, while an
 * event-body read composes the build-static adjacent chain and publishes only
 * this final generation before constructing a Session.
 *
 * The version is a single monotonic integer with no major/minor split. Whether
 * a bump is needed is decided by what the WRITER emits, never by what a newer
 * reader can accept: bump exactly when an older runtime could no longer handle
 * a new log with full semantic correctness ("parses without error" is not
 * correctness — silently skipping content that shapes reconstruction is a
 * wrong read). Only structural changes reach that bar: the header shape, the
 * {@link SessionEvent} envelope, core event semantics, or the surface
 * mechanism (the {@link SurfaceEventType} set and {@link SurfaceOp} variants).
 * Adding an ordinary event type does not bump — the per-event
 * {@link SessionEvent.ignorable} guard covers vocabulary growth instead. When
 * in doubt, bump: a near-identity upgrade step is almost free, a missed bump
 * makes older runtimes read new logs wrong silently. The released migration,
 * immutable prior-generation, and current fast-path rules are recorded in
 * `.agents/notes/implemented/architecture/2026-08-31-released-session-format-migrations.md`.
 */
export declare const SESSION_FORMAT_VERSION = 3;
/**
 * Immutable validated storage metadata, kept outside the conversation event log.
 */
export interface SessionHeader {
    /**
     * Current logical format version, stamped from {@link SESSION_FORMAT_VERSION}.
     * Historical physical headers are translated before entering this interface.
     */
    readonly version: typeof SESSION_FORMAT_VERSION;
    /** The session's id (mirrors the {@link Session}'s id). */
    readonly id: SessionId;
    /** Non-negative safe-integer Unix epoch milliseconds when the session was created. */
    readonly createdAt: number;
    /** Absolute working directory the session was created in (if any). */
    readonly cwd?: string;
    /** The session this one was forked from (seed lineage), if any. */
    readonly parentSession?: SessionId;
    /**
     * Whether this Session contains a fork-inherited event prefix. The exact prefix
     * length is Session state rather than ordinary header metadata.
     */
    readonly isSeeded: boolean;
    /**
     * Coarse product classification for a session created as a subagent child.
     * This is presentation metadata, not proof that the child is continuable.
     */
    readonly origin?: 'subagent';
    /**
     * Delegation depth: absent (zero) for a top-level session, parent depth + 1
     * for a subagent child. Persisted so a recursion budget survives restart and
     * resume — a runtime-only depth would reset a resumed child to top-level.
     */
    readonly delegationDepth?: number;
    /**
     * Id of the agent preset this session's agent was composed from, when the
     * deployment composes per session. Durable because the preset decides the
     * session's tools and prompt: a resume that restored a different composition
     * would replay history the model can no longer act on.
     */
    readonly agentPreset?: string;
}
/**
 * Options for creating a {@link Session} via the store. `seed` replays/forks
 * an existing event log; `meta` carries the caller-supplied storage fields the
 * store folds into a {@link SessionHeader}.
 */
export interface CreateSessionOptions {
    /** Initial replay or fork history supplied at construction. */
    readonly seed?: readonly SessionEvent[];
    /**
     * Exact fork-inherited prefix length when `meta.isSeeded` is true. The
     * constructor seed is exactly this inherited prefix; the constructor
     * appends the child-owned tagged marker at the cut.
     */
    readonly inheritedEventCount?: SessionLogOffset;
    /**
     * Storage metadata read once before publication. `isSeeded` marks fork
     * lineage; supplying replay history alone does not make it inherited.
     */
    readonly meta?: {
        readonly cwd?: string;
        readonly parentSession?: SessionId;
        readonly createdAt?: number;
        readonly isSeeded?: boolean;
        readonly origin?: 'subagent';
        readonly delegationDepth?: number;
        readonly agentPreset?: string;
    };
}
/**
 * Aliasing state of an adoptable Session seed. `shared-frozen` permits deeply
 * frozen aliases plus independently owned unfrozen values in the same seed.
 */
export type SessionSeedEventState = 'detached' | 'shared-frozen';
/**
 * Adoptable storage values transferred to {@link SessionStore.prepare}
 * without another copy or freeze pass.
 */
export interface RestoredSessionOptions {
    /** Events that are independently owned or already deeply frozen. */
    readonly seed: SessionEvent[];
    /** Independently owned storage metadata to validate and freeze in place. */
    readonly meta: SessionHeader;
    /** Exact number of fork-inherited leading events decoded from storage. */
    readonly inheritedEventCount: SessionLogOffset;
    /** Aliasing state carried from the operation that produced the seed. */
    readonly eventState: SessionSeedEventState;
}
/** Inputs accepted while constructing an unpublished Session. */
export type PrepareSessionOptions = (CreateSessionOptions & {
    readonly eventState?: undefined;
}) | RestoredSessionOptions;
/** Why an active agent driver was cancelled. */
export type AgentCancelCause = {
    readonly kind: 'user';
} | {
    readonly kind: 'parent';
} | {
    readonly kind: 'hook';
    readonly reason: string;
} | {
    readonly kind: 'disposed';
};
/** Durable cancellation cause, including imports whose original coarse record carried no cause. */
export type TurnEndCancelCause = AgentCancelCause | {
    readonly kind: 'legacy';
};
/**
 * Why a turn ended. Merge-extensible sum type.
 */
export interface TurnEndReasonMap {
    completed: {
        kind: 'completed';
    };
    /** A cancellation request interrupted the live turn. */
    aborted: {
        kind: 'aborted';
        reason: TurnEndCancelCause;
    };
    blocked: {
        kind: 'blocked';
    };
    /**
     * The turn failed. `error` is always a structured failure: the `LlmError`
     * facts verbatim, or `{ message: errorChain(error), code: 'UNKNOWN' }`
     * flattened from any other error.
     */
    error: {
        kind: 'error';
        error: LlmFailure;
    };
    /** At least one step reached its output-token ceiling, even if a plugin continued the turn. */
    'max-tokens': {
        kind: 'max-tokens';
    };
    /**
     * A crash-orphaned turn was closed after the fact: agent-loop resume appends
     * this closer for a stored log whose last turn never ended, and session-query
     * synthesizes it on cold reads. The loop never emits this marker live, and
     * the events recorded before the crash remain intact.
     */
    interrupted: {
        kind: 'interrupted';
    };
}
/** The union over {@link TurnEndReasonMap} — why a turn ended; plugins extend it by merging variants into the map. */
export type TurnEndReason = TurnEndReasonMap[keyof TurnEndReasonMap];
/**
 * Logged request state outside derived history: call config and tools. The
 * system prompt is derived history — surface node 0, a `system/message` event.
 * The latest full `request/header` snapshot reconstructs the header; canonical
 * empty optional fields are absent.
 */
export interface EpochHeader {
    /** The conversation's call configuration (provider, model, reasoning effort, and sampling scalars). */
    config: LlmCallConfig;
    /** Effective config fields materialized from the exact adapter rather than proposed by a caller. */
    adapterDefaults?: LlmCallConfigAdapterDefaults;
    /** Assembled tool schemas; absent for a tool-less request. */
    tools?: ToolSchema[];
}
/** Registration-bound metadata for one resolved model route. */
export interface RequestContext {
    /** Registered provider route the metadata belongs to. */
    provider: string;
    /** Provider-owned model id the metadata belongs to. */
    model: string;
    /** Maximum combined request and response context in tokens, when advertised. */
    contextWindow?: number;
    /** `'in-history'` when the route reads the latest `system` message at any position as the effective system prompt. */
    systemPromptUpdate?: SystemPromptUpdate;
}
/**
 * Why a `request/header` snapshot was appended: `'initial'` — the log's first
 * header (a new conversation); `'resume'` — a loop instance's first request
 * over a log that already has header events (process restart, fork seed);
 * `'change'` — a later request used a different header, with `startsSeries`
 * preserving a coincident series boundary; `'series'` — an unchanged header
 * began an explicitly distinct message series or followed a surface replacement.
 */
export type RequestHeaderReason = 'initial' | 'resume' | 'change' | 'series';
/**
 * The merge-extensible, append-only source of truth for an agent interaction.
 * Message history is derived from this log. Every event is lossless JSON and
 * sequence numbers stay contiguous. Assistant attempt events embed their exact
 * compact raw streams so persistence stores one durable settlement per attempt.
 */
export interface SessionEventMap {
    /**
     * Opens turn `turn` before the loop claims queued input or runs pre-step.
     * Rejection, empty input, cancellation, or failure may close it with no
     * step; otherwise the following identified `user/message` event or batch
     * records the messages entering the step.
     */
    'turn/start': {
        turn: number;
    };
    /**
     * Closes turn `turn` with the {@link TurnEndReason} that ended it. A turn
     * with no entered step has no `step/start` or `step/end`. The loop does not await a
     * flush at turn boundaries: `dsh-session-checkpoint-policy` owns the
     * per-request durability checkpoint, and consumers that read storage after
     * `whenIdle()` flush themselves. Success commits the turn; rejection is
     * reported live and does not prevent later work.
     */
    'turn/end': {
        turn: number;
        reason: TurnEndReason;
    };
    /** Opens step `step` of turn `turn` — one model call plus the tool executions it requested. */
    'step/start': {
        turn: number;
        step: number;
    };
    /** Closes step `step` of turn `turn`. */
    'step/end': {
        turn: number;
        step: number;
    };
    /**
     * A user-role message on the model-visible surface: a direct human prompt
     * (the queued message claimed for this turn), a synthetic `agent.inject()`
     * context (file-change notices, subdir AGENTS.md, skill content, cron
     * notifications, …), or an entered goal continuation round. All three
     * project their `content` verbatim; `source` tells them apart.
     */
    'user/message': UserMessage;
    /**
     * The rendered system prompt on the model-visible surface. The loop appends
     * the first one as surface node 0 before the step's first `user/message`.
     * A prepared in-history route can append nonempty changes in a continuing
     * series. An incapable route or new series normalizes text to the first system
     * node. Normalization empties nonempty later nodes, then rewrites the head if
     * needed, through logged per-node replacements. An empty rendering always
     * clears all active system nodes, leaving no older instructions model-visible.
     * Empty later nodes are dormant and project to no message; an empty head with
     * no active later node records "no system prompt". Restored nonempty text follows
     * the same route and series rule; empty nodes never restore older text.
     */
    'system/message': {
        turn: number;
        step: number;
        message: SystemMessage;
    };
    /**
     * Assembled assistant message for one step (derived history uses this).
     * Carries the step's `usage` when the adapter reported token accounting, so
     * the model output and its accounting travel together (there is no separate
     * usage record). `usage` is absent when the adapter reported none. A turn
     * cancelled mid-stream finalizes its delivered text/reasoning prefix as this
     * event with `interrupted: true`; undispatched tool calls are absent. The
     * marker distinguishes that prefix without re-deriving interruption from turn
     * boundaries. An aborted turn with no such event streamed no visible content.
     */
    'assistant/message': {
        turn: number;
        step: number;
        message: AssistantMessage;
        /** Exact timed model stream, compacted without joining delta boundaries. */
        stream: AssistantStreamRecord[];
        usage?: TokenUsage;
        interrupted?: true;
    };
    /**
     * One model attempt that committed no surface message. The embedded stream
     * preserves a failed, retried, cancelled, or stream-error attempt that
     * reached settlement without fabricating model-visible history.
     */
    'assistant/attempt': {
        turn: number;
        step: number;
        stream: AssistantStreamRecord[];
    };
    /**
     * The model requested one tool invocation: `name` with the raw `arguments`
     * JSON string exactly as the model produced it (unparsed). `callId` pairs the
     * call with its `tool/result`.
     */
    'tool/call': {
        turn: number;
        step: number;
        callId: ToolCallId;
        name: string;
        arguments: string;
    };
    /**
     * A completed tool call's model-facing result, optional internal failure
     * identity and user-facing reason, and optional tool-private `meta`
     * presentation payload. The reason remains outside the model-facing message.
     * `meta` is
     * opaque to the core (the producing tool owns its shape and reads it back in
     * `presentResult`) but MUST be JSON-serializable: `Session.append`
     * runtime-validates all event data with `isJsonValue`, so a non-serializable
     * `meta` is rejected at the source, and the durable log reproduces the
     * identical card on replay. Absent
     * unless the tool attaches one (e.g. `dsh-tool-fs` carries its result-time
     * contextual diff here).
     */
    'tool/result': {
        turn: number;
        step: number;
        message: ToolResultMessage;
        /**
         * Optional failure identity and raw user-facing reason, outside model content;
         * allowed only when the tool-result block has `isError: true`.
         */
        error?: {
            name: string;
            code: string;
            reason?: string;
        };
        meta?: JsonValue;
    };
    /**
     * Full header for the next request, appended inside its step before dispatch.
     * It is log-only; the latest snapshot reconstructs the request header.
     */
    'request/header': {
        header: EpochHeader;
        reason: RequestHeaderReason;
        /** A changed header also begins a distinct model-message series. */
        startsSeries?: true;
    };
    /**
     * Route metadata for the next request, logged only when the route, capacity,
     * or system prompt update mode changes. It does not participate in request
     * reconstruction or header equality. Prompt admission uses the bound prepared
     * call's capability, not this snapshot from an earlier request.
     */
    'request/context': RequestContext;
    /**
     * Marks the end of a constructor seed. Events before it have smaller seq
     * values and came from the seed (resume, fork, or replay); this lifecycle
     * produced none of them. This log-only event is the durable projection of
     * {@link Session.firstLiveSeq}.
     *
     * A fresh fork child owns one `{ inherited: true }` marker at its exact
     * inherited-prefix cut, even when that prefix ends in an ancestor marker.
     * The last tagged marker is the current Session's cut; untagged markers keep
     * ordinary restore and replay lifecycle boundaries.
     *
     * `Session`'s constructor is the only legitimate writer. The invariant
     * companion deliberately constrains nothing here, so a plugin appending one
     * would silently classify every live bracket before it as seed history.
     *
     * An owner of a standalone open/close bracket (`compaction/start` …
     * `compaction/end`) reads it because seed history and live work are otherwise
     * byte-identical: an unmatched opening marker before this event belongs to
     * an ended lifecycle, whatever ended it. NOT a liveness signal about other
     * writers — a concurrently live session holds its own boundary elsewhere,
     * so tolerating concurrent writers needs a signal beyond the log.
     */
    'session/end-seed': {
        inherited?: true;
    };
}
/** The appendable event-type keys of {@link SessionEventMap}, plugin-merged extensions included. */
export type SessionEventType = keyof SessionEventMap;
/**
 * The subset of {@link SessionEventType} values whose events produce LLM
 * messages and are eligible to appear on the ordered surface. Only these
 * event types may carry {@link SurfaceOp}; system, user, and tool events may also cite
 * earlier sources through {@link SessionEvent.sourceEventSeqs}.
 */
export type SurfaceEventType = 'system/message' | 'user/message' | 'assistant/message' | 'tool/result';
/** A message-producing event carrying its required surface operation. */
export type SurfaceEvent = SessionEvent<SurfaceEventType>;
/**
 * How a session event entered the ordered surface. Only valid on
 * {@link SurfaceEventType} events.
 *
 * - `'append'`: added to the tail — normal path for user/assistant/tool
 *   messages.
 * - `{ op: 'replace', startSeq, endSeq }`: replaces surface nodes from `startSeq`
 *   (inclusive) through `endSeq` (inclusive) with this node. Both must exist as
 *   surface nodes in the current surface. `startSeq === endSeq` replaces a single
 *   node. The node's {@link SessionEvent.sourceEventSeqs} must include every
 *   shadowed surface node. Used by compaction; any surface-replacing producer
 *   may use it.
 */
export type SurfaceOp = 'append' | {
    op: 'replace';
    startSeq: SessionSeq;
    endSeq: SessionSeq;
};
/**
 * Surface placement and cited source-event seqs for {@link Session.append}. Required on
 * message-producing events and forbidden on log-only events.
 */
export type SurfaceIntent<T extends SurfaceEventType = SurfaceEventType> = {
    surfaceOp: SurfaceOp;
} & (T extends 'assistant/message' ? {
    /** Assistant messages embed their provider stream instead of citing source events. */
    sourceEventSeqs?: never;
} : {
    /** Complete non-empty set of known earlier source-event seqs. */
    sourceEventSeqs?: SessionSeq[];
});
/**
 * One immutable entry in the session log.
 *
 * A proper discriminated union over `type` (not independent `type`/`data`
 * unions), so `switch (event.type)` narrows `event.data` without casts.
 *
 * The {@link sourceEventSeqs} and {@link surfaceOp} fields are conditional:
 * they only exist on {@link SurfaceEventType} variants (`system/message`, `user/message`,
 * `assistant/message`, `tool/result`).
 * Non-surface events (boundary markers, attempts, errors) never carry
 * surface metadata — the compiler enforces this at `Session.append()`
 * call sites.
 */
export type SessionEvent<T extends SessionEventType = SessionEventType> = {
    [K in SessionEventType]: {
        type: K;
        /** Monotonic sequence number within the session. */
        seq: SessionSeq;
        /** Unix epoch milliseconds. */
        time: number;
        data: SessionEventMap[K];
        /**
         * Marks an event a reader may safely skip when it does not recognize
         * `type`. Absent means required: a reader meeting an unrecognized type
         * without this marker MUST refuse to reconstruct the session instead of
         * silently dropping the event, because an unrecognized required event may
         * change how the rest of the log is interpreted. A writer sets `true` only
         * on purely informational records whose loss cannot affect reconstruction;
         * defaulting to required means a forgotten marker over-refuses (an
         * inconvenience) rather than silently resuming a gutted session.
         */
        ignorable?: true;
    } & (K extends SurfaceEventType ? SurfaceIntent<K> : {
        surfaceOp?: never;
        sourceEventSeqs?: never;
    });
}[T];
declare module '@ankdesh/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        /** The named Session does not exist; produced by every layer that resolves a SessionId. */
        'session/not-found': {
            readonly sessionId: SessionId;
        };
    }
}
//# sourceMappingURL=types.d.ts.map