/**
 * Package-owned relational invariants for the session event log. Load this
 * companion beside `@ankdesh/dsh-invariants` to enable the checks.
 *
 * @module @ankdesh/dsh-session/invariant
 */
import type { Context } from '@ankdesh/cordis';
/** Cordis companion plugin name. */
export declare const name = "session-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register the session invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map