import { Context, Service } from '@ankdesh/cordis';
import type { Agent } from '@ankdesh/dsh-agent';
import { SessionId } from '@ankdesh/dsh-session';
import type { JsonValue } from '@ankdesh/dsh-util-values';
import type { EventSystemDefinition, EventSystemMembership, EventSystemSnapshot, ExecutionLimits, PublishEventInput, EventId, DeliveryId, WaitId, WaitRequest, EventWait } from './types.ts';
export type * from './types.ts';
export { validateDefinition } from './ledger.ts';
declare module '@ankdesh/cordis' {
    interface Context {
        eventSystems: EventSystemService;
    }
}
/** Owns specialists and scheduling; the primary native agent remains owned by its caller. */
export default class EventSystemService extends Service {
    static inject: string[];
    /** Resolves after domain loading and human-gated restart reconstruction. */
    readonly ready: Promise<void>;
    private readonly definitions;
    private readonly composed;
    private sealed;
    private domain;
    private _ledger;
    private get ledger();
    private isStopping;
    private stopping;
    private turns;
    private handles;
    private pumps;
    private jobs;
    private retryTimers;
    private timeLimits;
    constructor(ctx: Context);
    /**
     * Register an exact trusted template; the returned disposer removes only this contribution.
     * @param input - trusted resolved definition.
     * @returns disposer for this exact registration.
     */
    registerDefinition(input: EventSystemDefinition): () => void;
    /**
     * Resolve an exact template version; missing configuration fails before conversation execution.
     * @param id - catalog identity.
     * @param version - exact catalog version.
     * @returns registered immutable definition.
     */
    definition(id: string, version: string): EventSystemDefinition;
    /** Prevent new catalog registrations after trusted startup composition. */
    seal(): void;
    /**
     * Locate a member by native session identity; routing never accepts another conversation.
     * @param sessionId - native member identity.
     * @returns owning conversation and role, if configured.
     */
    membership(sessionId: SessionId): EventSystemMembership | undefined;
    /**
     * Read committed state.
     * @param id - primary conversation identity.
     * @returns committed pinned state, if configured.
     */
    get(id: SessionId): EventSystemSnapshot | undefined;
    /**
     * Pin a new conversation or attach to its existing configuration without rearming recovered state.
     * @param primary - caller-owned native primary agent.
     * @param mode - immutable conversation execution mode.
     * @param definition - resolved trusted roster and subscriptions.
     * @param limits - explicit aggregate resource bounds.
     * @returns existing or newly pinned conversation state.
     */
    attach(primary: Agent, mode: EventSystemSnapshot['mode'], definition: EventSystemDefinition, limits: ExecutionLimits): Promise<EventSystemSnapshot>;
    private compose;
    /**
     * Publish on behalf of the exact live calling member; producer and causal identity are host-owned.
     * @param agent - exact live initiator.
     * @param type - declared permitted event type.
     * @param payload - JSON payload validated against the event schema.
     * @param dedupeKey - stable producer key for the same result.
     * @returns durably committed event identity.
     */
    publishAgent(agent: Agent, type: string, payload: JsonValue, dedupeKey: string): Promise<EventId>;
    /**
     * Admit a trusted application/user event after payload validation and before scheduling.
     * @param id - primary conversation identity.
     * @param input - trusted validated publication request.
     * @param revision - optional exact human-observed revision.
     * @returns durably committed event identity.
     */
    publishHost(id: SessionId, input: PublishEventInput, revision?: number): Promise<EventId>;
    /**
     * Pause new admissions while letting the current tool result settle, for host review gates.
     * @param id - primary conversation identity.
     * @param reason - visible host review reason.
     * @returns committed state without cancelling the current tool.
     */
    hold(id: SessionId, reason: string): Promise<EventSystemSnapshot>;
    /**
     * Human lifecycle mutation using the exact observed revision; Resume preserves all spending.
     * @param id - primary conversation identity.
     * @param revision - exact observed revision.
     * @param action - human-authorized lifecycle change.
     * @returns committed state after scheduling or quiescence.
     */
    control(id: SessionId, revision: number, action: 'pause' | 'resume' | 'stop'): Promise<EventSystemSnapshot>;
    /**
     * Explicitly retry uncertain work; the caller must acknowledge possible prior effects.
     * @param id - primary conversation identity.
     * @param revision - exact observed revision.
     * @param deliveryId - failed or interrupted attempt identity.
     * @param acknowledgeUncertainty - explicit human acknowledgement of possible prior effects.
     * @returns committed state retaining the previous attempt.
     */
    retry(id: SessionId, revision: number, deliveryId: DeliveryId, acknowledgeUncertainty: boolean): Promise<EventSystemSnapshot>;
    /**
     * List persisted conversations for trusted source adapters.
     * @returns all pinned conversation snapshots.
     */
    list(): EventSystemSnapshot[];
    /**
     * Publish a source observation only while the owning conversation has active authority.
     * @param id - owning conversation.
     * @param input - validated source outbox item.
     * @returns durable event identity for idempotent source acknowledgement.
     */
    publishTrigger(id: SessionId, input: PublishEventInput): Promise<EventId>;
    /**
     * Persist a future correlated wait and disarm native goal continuation without spending rounds.
     * @param agent - exact live member executing the waiting tool.
     * @param request - declared event or host-human response request.
     * @returns committed wait with its host-generated response identity.
     */
    wait(agent: Agent, request: WaitRequest): Promise<EventWait>;
    /**
     * Answer one exact human wait; stale answers cannot wake another activation.
     * @param id - owning conversation.
     * @param revision - observed execution revision.
     * @param waitId - current human response identity.
     * @param answer - bounded human answer logged through the native inbox.
     * @returns durable response event identity.
     */
    answerWait(id: SessionId, revision: number, waitId: WaitId, answer: string): Promise<EventId>;
    private resumeResolvedGoals;
    private queueSafeRetries;
    private track;
    private schedule;
    private pump;
    private observe;
    private armRetryTimer;
    private readonly requestBudgetRoutes;
    /** Route a trusted host phase's spending to its existing primary conversation.
     * @param agent - Exact live phase conversation.
     * @param conversationId - Existing primary budget identity.
     * @returns Scoped registration disposer.
     */
    routeRequestBudget(agent: Agent, conversationId: SessionId): () => void;
    private meter;
    private updateTimeLimit;
    private close;
}
//# sourceMappingURL=index.d.ts.map