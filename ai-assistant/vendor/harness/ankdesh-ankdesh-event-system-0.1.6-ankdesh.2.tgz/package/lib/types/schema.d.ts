/** Validation of configuration and durable records at file/storage boundaries. */
import { z } from 'zod';
import type { ZodType } from 'zod';
import type { MessageId } from '@ankdesh/dsh-llm';
import type { SessionId } from '@ankdesh/dsh-session';
import type { JsonValue } from '@ankdesh/dsh-util-values';
import type { EventId, DeliveryId, RequestId, ActivationId, EventSystemDefinition, WaitId } from './types.ts';
/** Limits are explicit at the host admission call; configuration has no silent fallback. */
export declare const limitsSchema: z.ZodObject<{
    maxRounds: z.ZodNumber;
    maxRequests: z.ZodNumber;
    maxTokens: z.ZodNumber;
    maxActiveMillis: z.ZodNumber;
    maxMembers: z.ZodNumber;
    maxConcurrency: z.ZodNumber;
    maxPending: z.ZodNumber;
    maxEvents: z.ZodNumber;
    maxPayloadBytes: z.ZodNumber;
    maxDepth: z.ZodNumber;
    maxOutputTokens: z.ZodNumber;
}, z.core.$strict>;
/** Durable waits retain exact response matching and optional native goal revisions. */
export declare const waitSchema: z.ZodObject<{
    id: z.ZodPipe<z.ZodString, z.ZodTransform<WaitId, string>>;
    member: z.ZodString;
    kind: z.ZodEnum<{
        human: "human";
        event: "event";
        review: "review";
    }>;
    reason: z.ZodString;
    eventType: z.ZodString;
    matchKey: z.ZodString;
    matchValue: z.ZodString;
    state: z.ZodEnum<{
        waiting: "waiting";
        resolved: "resolved";
        cancelled: "cancelled";
    }>;
    afterEvents: z.ZodNumber;
    causation: z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>>;
    response: z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>>;
    goal: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Resolved prompt text and subscriptions are stored with the conversation. */
export declare const definitionSchema: ZodType<EventSystemDefinition>;
/** Each event and all of its resolved deliveries commit in one record update. */
export declare const snapshotSchema: z.ZodObject<{
    conversationId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    revision: z.ZodNumber;
    mode: z.ZodEnum<{
        goal: "goal";
        orchestrated: "orchestrated";
    }>;
    status: z.ZodEnum<{
        active: "active";
        paused: "paused";
        stopped: "stopped";
        "needs-resume": "needs-resume";
        exhausted: "exhausted";
    }>;
    waits: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodPipe<z.ZodString, z.ZodTransform<WaitId, string>>;
        member: z.ZodString;
        kind: z.ZodEnum<{
            human: "human";
            event: "event";
            review: "review";
        }>;
        reason: z.ZodString;
        eventType: z.ZodString;
        matchKey: z.ZodString;
        matchValue: z.ZodString;
        state: z.ZodEnum<{
            waiting: "waiting";
            resolved: "resolved";
            cancelled: "cancelled";
        }>;
        afterEvents: z.ZodNumber;
        causation: z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>>;
        response: z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>>;
        goal: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    reason: z.ZodString;
    definition: z.ZodType<EventSystemDefinition, unknown, z.core.$ZodTypeInternals<EventSystemDefinition, unknown>>;
    digest: z.ZodString;
    limits: z.ZodObject<{
        maxRounds: z.ZodNumber;
        maxRequests: z.ZodNumber;
        maxTokens: z.ZodNumber;
        maxActiveMillis: z.ZodNumber;
        maxMembers: z.ZodNumber;
        maxConcurrency: z.ZodNumber;
        maxPending: z.ZodNumber;
        maxEvents: z.ZodNumber;
        maxPayloadBytes: z.ZodNumber;
        maxDepth: z.ZodNumber;
        maxOutputTokens: z.ZodNumber;
    }, z.core.$strict>;
    members: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
        created: z.ZodBoolean;
    }, z.core.$strict>>;
    rounds: z.ZodArray<z.ZodString>;
    requests: z.ZodArray<z.ZodObject<{
        id: z.ZodPipe<z.ZodString, z.ZodTransform<RequestId, string>>;
        tokens: z.ZodNumber;
        activeMillis: z.ZodNumber;
        startedAt: z.ZodNumber;
        settled: z.ZodBoolean;
    }, z.core.$strict>>;
    events: z.ZodArray<z.ZodObject<{
        id: z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>;
        type: z.ZodString;
        payload: z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>;
        producer: z.ZodString;
        dedupeKey: z.ZodString;
        causation: z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>>;
        correlation: z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>;
        depth: z.ZodNumber;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>;
    deliveries: z.ZodArray<z.ZodObject<{
        id: z.ZodPipe<z.ZodString, z.ZodTransform<DeliveryId, string>>;
        eventId: z.ZodPipe<z.ZodString, z.ZodTransform<EventId, string>>;
        subscription: z.ZodString;
        target: z.ZodString;
        messageId: z.ZodPipe<z.ZodString, z.ZodTransform<MessageId, string>>;
        activationId: z.ZodPipe<z.ZodString, z.ZodTransform<ActivationId, string>>;
        attempt: z.ZodNumber;
        retryOf: z.ZodNullable<z.ZodPipe<z.ZodString, z.ZodTransform<DeliveryId, string>>>;
        state: z.ZodEnum<{
            cancelled: "cancelled";
            pending: "pending";
            dispatching: "dispatching";
            accepted: "accepted";
            completed: "completed";
            failed: "failed";
            interrupted: "interrupted";
        }>;
        turn: z.ZodNullable<z.ZodNumber>;
        error: z.ZodString;
        notBefore: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
//# sourceMappingURL=schema.d.ts.map