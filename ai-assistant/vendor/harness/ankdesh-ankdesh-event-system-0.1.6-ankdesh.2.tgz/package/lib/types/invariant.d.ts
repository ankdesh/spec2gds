/** Native inbox receipts and committed delivery states must describe the same activation. */
import type { Context } from '@ankdesh/cordis';
/** Cordis invariant companion name. */
export declare const name = "event-system-invariant";
/** Registry required to own this contribution. */
export declare const inject: string[];
/**
 * Own the delivery/native-execution observation through companion disposal.
 * @param ctx - context carrying the invariant registry.
 */
export declare const apply: (ctx: Context) => void;
//# sourceMappingURL=invariant.d.ts.map