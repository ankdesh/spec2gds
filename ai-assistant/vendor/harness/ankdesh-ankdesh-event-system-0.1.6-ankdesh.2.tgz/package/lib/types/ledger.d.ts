import type { KvTable } from '@ankdesh/dsh-storage-domain';
import type { SessionId } from '@ankdesh/dsh-session';
import type { EventSystemSnapshot, EventSystemDefinition, ExecutionLimits, PublishEventInput, EventId, RequestId } from './types.ts';
/**
 * Reject unresolvable references and unsupported payload schemas before pinning.
 * @param input - untrusted file or persisted definition.
 * @returns validated detached definition.
 */
export declare function validateDefinition(input: unknown): EventSystemDefinition;
/** One serialized table update owns event routing and aggregate resource reservations. */
export declare class EventSystemLedger {
    private readonly records;
    private readonly creating;
    constructor(records: KvTable<SessionId, EventSystemSnapshot>);
    /**
     * Read immutable committed state.
     * @param id - primary conversation identity.
     * @returns committed state, if present.
     */
    get(id: SessionId): EventSystemSnapshot | undefined;
    /**
     * List configured conversations.
     * @returns committed conversation snapshots.
     */
    list(): EventSystemSnapshot[];
    /**
     * Create a pinned system once; reopening never replaces its definition or budget.
     * @param id - primary conversation identity.
     * @param mode - execution mode.
     * @param input - resolved definition to pin.
     * @param limits - explicit host resource bounds.
     * @returns new committed pinned system.
     */
    create(id: SessionId, mode: EventSystemSnapshot['mode'], input: EventSystemDefinition, limits: ExecutionLimits): Promise<EventSystemSnapshot>;
    /**
     * Atomically update one system; revision increments only after a durable write.
     * @param id - primary conversation identity.
     * @param transform - serialized immutable snapshot mutation.
     * @returns committed state with incremented revision.
     */
    update(id: SessionId, transform: (snapshot: EventSystemSnapshot) => EventSystemSnapshot): Promise<EventSystemSnapshot>;
    /**
     * Persist a validated event with all deliveries, or return its exact duplicate identity.
     * @param id - primary conversation identity.
     * @param input - typed publication request.
     * @param host - whether the caller owns trusted host publication authority.
     * @returns durable event identity, including exact duplicates.
     */
    publish(id: SessionId, input: PublishEventInput, host?: boolean, activeOnly?: boolean, revision?: number): Promise<EventId>;
    /**
     * Charge a native turn once; duplicate pre-step calls do not charge again.
     * @param id - primary conversation identity.
     * @param key - native session and turn identity.
     * @returns whether this turn may execute.
     */
    admitRound(id: SessionId, key: string): Promise<boolean>;
    /**
     * Reserve a request before contacting a provider; a crash retains token reservations.
     * @param id - primary conversation identity.
     * @param tokens - conservative input and output reservation.
     * @returns reservation identity if admitted.
     */
    reserveRequest(id: SessionId, tokens: number): Promise<RequestId | undefined>;
    /**
     * Settle actual disjoint token counts; missing usage keeps the conservative reservation.
     * @param id - primary conversation identity.
     * @param requestId - exact reservation to settle.
     * @param tokens - disjoint reported usage; undefined retains the reservation.
     */
    settleRequest(id: SessionId, requestId: RequestId, tokens: number | undefined): Promise<void>;
    /**
     * Reconstruct visible interruption without granting authority to run.
     */
    recover(): Promise<void>;
}
/**
 * Validate persisted relationships before any member can execute after restart.
 * @param snapshot - persisted conversation record.
 */
export declare function assertSnapshotIntegrity(snapshot: EventSystemSnapshot): void;
//# sourceMappingURL=ledger.d.ts.map