/** Agent-scoped event tools; no roster, subscription, or budget mutation capabilities. */
import type { Context } from '@ankdesh/cordis';
import type EventSystemService from './index.ts';
/**
 * Install model-facing consumers in a member's scoped registry.
 * @param ctx - member scoped tool registry.
 * @param systems - owning event service.
 * @param allowed - exact configured member tool names.
 */
export declare function installEventTools(ctx: Context, systems: EventSystemService, allowed: readonly string[]): void;
//# sourceMappingURL=tools.d.ts.map