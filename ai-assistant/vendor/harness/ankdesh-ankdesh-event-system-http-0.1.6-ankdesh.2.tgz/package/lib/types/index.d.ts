import { Context, Service } from '@ankdesh/cordis';
import z from '@ankdesh/schemastery';
import type { SessionId } from '@ankdesh/dsh-session';
import type { HttpSourceId, HttpSourceInput, HttpSourceRecord } from './types.ts';
export type * from './types.ts';
/** Host-owned network and traffic bounds. */
export interface Config {
    /** Exact approved origins; redirects and URL credentials are forbidden. */
    allowedOrigins: string[];
    /** Scheduler tick; unchanged checks invoke no model. */
    tickMillis: number;
    /** Minimum accepted source interval. */
    minIntervalMillis: number;
    /** Maximum backoff and accepted source interval. */
    maxIntervalMillis: number;
    /** Deadline covering headers and the entire response body. */
    timeoutMillis: number;
    /** Complete response byte limit before JSON parsing. */
    maxResponseBytes: number;
    /** Maximum number of retained sources per conversation. */
    maxSourcesPerConversation: number;
    /** Maximum number of retained sources across the process. */
    maxTotalSources: number;
    /** Concurrent network checks; at most one per source. */
    maxConcurrentChecks: number;
    /** Consecutive failures before human re-enable is required. */
    maxFailures: number;
}
export declare const Config: z<Config>;
declare module '@ankdesh/cordis' {
    interface Context {
        eventHttpSources: HttpSourceService;
    }
}
/** Owns read-only network requests, cursor storage, and the publication outbox. */
export default class HttpSourceService extends Service {
    private readonly config;
    static inject: string[];
    static Config: z<Config>;
    /** Resolves after persisted definitions and cursors are validated. */
    readonly ready: Promise<void>;
    private domain;
    private stopping;
    private readonly adding;
    private readonly jobs;
    private readonly aborts;
    constructor(ctx: Context, config: Config);
    private get records();
    private validate;
    /**
     * Read source configuration, cursors, errors, and enabled state for one conversation.
     * @param id - owning conversation.
     * @returns committed source records, with credential values excluded.
     */
    list(id: SessionId): HttpSourceRecord[];
    /**
     * Register one immutable human-approved source; the first unchanged observation is a baseline.
     * @param id - owning conversation; routing is pinned to its declared event subscriptions.
     * @param input - explicit URL, condition, and traffic settings.
     * @returns committed source identity and initial cursor.
     */
    add(id: SessionId, input: HttpSourceInput): Promise<HttpSourceRecord>;
    /**
     * Human enable/disable with the observed source revision; enabling retains cursors and outboxes.
     * @param conversationId - exact owning conversation.
     * @param id - source identity.
     * @param revision - observed source revision.
     * @param enabled - human polling authority.
     * @returns committed source state.
     */
    control(conversationId: SessionId, id: HttpSourceId, revision: number, enabled: boolean): Promise<HttpSourceRecord>;
    private tick;
    private acknowledge;
    private check;
}
//# sourceMappingURL=index.d.ts.map