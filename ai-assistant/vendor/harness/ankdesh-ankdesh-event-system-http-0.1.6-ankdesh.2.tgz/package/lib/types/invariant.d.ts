/** A source acknowledgement must identify its independently committed event. */
import type { Context } from '@ankdesh/cordis';
/** Cordis companion identity. */
export declare const name = "event-http-source-invariant";
/** Native observation owners required by the companion. */
export declare const inject: string[];
/**
 * Own the cursor/publication observation through companion disposal.
 * @param ctx - native invariant registry and event-system owner.
 */
export declare const apply: (ctx: Context) => void;
//# sourceMappingURL=invariant.d.ts.map