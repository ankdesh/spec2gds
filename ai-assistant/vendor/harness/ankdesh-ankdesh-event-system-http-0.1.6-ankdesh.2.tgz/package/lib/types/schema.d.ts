/** Validation at HTTP registration and persistence boundaries. */
import { z } from 'zod';
import type { SessionId } from '@ankdesh/dsh-session';
import type { HttpSourceId } from './types.ts';
/** Explicit source settings; no executable predicates or model-owned URLs. */
export declare const sourceSchema: z.ZodObject<{
    url: z.ZodURL;
    eventType: z.ZodString;
    pointer: z.ZodString;
    condition: z.ZodEnum<{
        changed: "changed";
        equals: "equals";
    }>;
    expectedJson: z.ZodOptional<z.ZodString>;
    intervalMillis: z.ZodNumber;
    debounceMillis: z.ZodNumber;
    emitInitial: z.ZodBoolean;
    authorizationEnv: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/** Durable outbox prevents a crash between event commit and source acknowledgement from duplicating delivery. */
export declare const recordSchema: z.ZodObject<{
    id: z.ZodPipe<z.ZodString, z.ZodTransform<HttpSourceId, string>>;
    conversationId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
    revision: z.ZodNumber;
    definition: z.ZodObject<{
        url: z.ZodURL;
        eventType: z.ZodString;
        pointer: z.ZodString;
        condition: z.ZodEnum<{
            changed: "changed";
            equals: "equals";
        }>;
        expectedJson: z.ZodOptional<z.ZodString>;
        intervalMillis: z.ZodNumber;
        debounceMillis: z.ZodNumber;
        emitInitial: z.ZodBoolean;
        authorizationEnv: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    enabled: z.ZodBoolean;
    sequence: z.ZodNumber;
    observed: z.ZodNullable<z.ZodObject<{
        digest: z.ZodString;
        valueJson: z.ZodString;
    }, z.core.$strict>>;
    candidate: z.ZodNullable<z.ZodObject<{
        digest: z.ZodString;
        valueJson: z.ZodString;
        since: z.ZodNumber;
    }, z.core.$strict>>;
    pending: z.ZodNullable<z.ZodObject<{
        digest: z.ZodString;
        valueJson: z.ZodString;
        sequence: z.ZodNumber;
        previousDigest: z.ZodString;
    }, z.core.$strict>>;
    nextCheckAt: z.ZodNumber;
    failures: z.ZodNumber;
    error: z.ZodString;
}, z.core.$strict>;
//# sourceMappingURL=schema.d.ts.map